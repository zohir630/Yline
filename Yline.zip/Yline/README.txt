Y,line  (com.yline.app)
Java + Firebase Auth + Realtime Database.
Realtime DB structure:
  users/{uid}  -> name, email, role ("seller" | "regular")
  posts/{id}   -> title, description, price, sellerId, sellerName, timestamp
Firebase console:
  1. Authentication -> Sign-in method -> Email/Password ENABLE
  2. Realtime Database -> Rules (test):
     { "rules": { ".read": "auth != null", ".write": "auth != null" } }
Build: push to GitHub -> Actions -> Build APK -> download artifact.

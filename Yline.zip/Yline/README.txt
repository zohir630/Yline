Y,line  (com.yline.app)  -  Java + Firebase Auth + Realtime Database + Google Sign-In

Debug keystore (app/debug.keystore) is fixed so the SHA-1 never changes:
  SHA1: A9:C8:78:FC:D2:7E:2D:2B:98:71:34:51:B3:72:00:D3:9B:A4:01:5B
Add it in Firebase Console -> Project settings -> Your apps (com.yline.app) -> Add fingerprint.

Firebase Console:
 1. Authentication -> Sign-in method -> enable Email/Password AND Google
 2. Realtime Database -> Rules:
{
  "rules": {
    ".read": "auth != null",
    ".write": "auth != null",
    "users": { ".indexOn": ["email"] }
  }
}

DB structure: users, jobs, proposals, contracts, chats, notifications, invites, userdata

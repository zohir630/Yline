package com.yline.app;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.view.View;
import android.widget.TextView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.Collections;
import java.util.List;

public class ContractsFragment extends BaseListFragment<Contract> {
    @Override protected int itemLayout() { return R.layout.item_row; }
    @Override protected String emptyText() { return "এখনো কোনো contract নেই"; }
    @Override protected DatabaseReference source() { return FirebaseDatabase.getInstance().getReference("contracts"); }

    @Override
    protected void collect(DataSnapshot snap, List<Contract> out) {
        for (DataSnapshot d : snap.getChildren()) {
            Contract c = d.getValue(Contract.class);
            if (c != null && (uid.equals(c.clientId) || uid.equals(c.freelancerId))) {
                c.id = d.getKey();
                out.add(c);
            }
        }
        Collections.sort(out, (a, b) -> Long.compare(b.timestamp, a.timestamp));
    }

    @Override
    protected void bind(View v, Contract c) {
        boolean iAmClient = uid.equals(c.clientId);
        ((TextView) v.findViewById(R.id.tvTitle)).setText(Ui.nz(c.jobTitle));
        ((TextView) v.findViewById(R.id.tvSub)).setText(
            (iAmClient ? "Freelancer: " + Ui.nz(c.freelancerName) : "Client: " + Ui.nz(c.clientName))
                + "  •  $" + c.price);
        ((TextView) v.findViewById(R.id.tvTime)).setText(Ui.timeAgo(c.timestamp));
        TextView b = v.findViewById(R.id.tvBadge);
        b.setVisibility(View.VISIBLE);
        b.setText(Ui.nz(c.status).toUpperCase());
        b.setBackgroundTintList(ColorStateList.valueOf(Ui.statusColor(c.status)));
    }

    @Override
    protected void onItemClick(Contract c) {
        boolean iAmClient = uid.equals(c.clientId);
        Intent i = new Intent(getActivity(), ChatActivity.class)
            .putExtra("chatId", c.id)
            .putExtra("title", iAmClient ? c.freelancerName : c.clientName);
        Ui.open(requireActivity(), i);
    }
}

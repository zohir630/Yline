package com.yline.app;

import android.os.Bundle;
import android.view.*;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.*;
import java.util.*;

public class HomeFragment extends Fragment {
    private final List<Post> posts = new ArrayList<>();
    private PostAdapter adapter;
    private DatabaseReference ref;
    private ValueEventListener listener;
    private TextView empty;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup c, @Nullable Bundle s) {
        View v = inf.inflate(R.layout.fragment_home, c, false);
        empty = v.findViewById(R.id.tvEmpty);
        RecyclerView rv = v.findViewById(R.id.rvPosts);
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new PostAdapter(posts);
        rv.setAdapter(adapter);
        ref = FirebaseDatabase.getInstance().getReference("posts");
        listener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snap) {
                posts.clear();
                for (DataSnapshot d : snap.getChildren()) {
                    Post p = d.getValue(Post.class);
                    if (p != null) { p.id = d.getKey(); posts.add(p); }
                }
                Collections.sort(posts, (a, b) -> Long.compare(b.timestamp, a.timestamp));
                adapter.notifyDataSetChanged();
                empty.setVisibility(posts.isEmpty() ? View.VISIBLE : View.GONE);
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };
        ref.addValueEventListener(listener);
        return v;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (ref != null && listener != null) ref.removeEventListener(listener);
    }
}

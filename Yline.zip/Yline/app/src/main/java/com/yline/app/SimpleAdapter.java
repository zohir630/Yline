package com.yline.app;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class SimpleAdapter<T> extends RecyclerView.Adapter<SimpleAdapter.VH> {
    public interface Binder<T> { void bind(View v, T item); }

    public static class VH extends RecyclerView.ViewHolder {
        public VH(View v) { super(v); }
    }

    private final int layout;
    private final List<T> items;
    private final Binder<T> binder;

    public SimpleAdapter(int layout, List<T> items, Binder<T> binder) {
        this.layout = layout;
        this.items = items;
        this.binder = binder;
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup p, int type) {
        return new VH(LayoutInflater.from(p.getContext()).inflate(layout, p, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int i) { binder.bind(h.itemView, items.get(i)); }

    @Override
    public int getItemCount() { return items.size(); }
}

package com.yline.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JobDetailActivity extends AppCompatActivity {
    private String jobId, uid, myName = "User";
    private Job job;
    private boolean proposalSent = false, ownerListening = false;
    private DatabaseReference db, jobRef, myPropRef, propsRef;
    private ValueEventListener jobL, myPropL, propsL;
    private MaterialButton btnApply;
    private LinearLayout propList;
    private TextView noProps;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_job_detail);
        jobId = getIntent().getStringExtra("jobId");
        uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        db = FirebaseDatabase.getInstance().getReference();
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        Ui.enter(findViewById(R.id.content));

        btnApply = findViewById(R.id.btnApply);
        propList = findViewById(R.id.propList);
        noProps = findViewById(R.id.tvNoProps);
        Ui.press(btnApply);
        btnApply.setOnClickListener(v -> showProposalSheet());

        db.child("users").child(uid).child("name").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                String n = s.getValue(String.class);
                if (n != null) myName = n;
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        });

        jobRef = db.child("jobs").child(jobId);
        jobL = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                Job j = s.getValue(Job.class);
                if (j == null) { finish(); return; }
                j.id = jobId;
                job = j;
                render();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };
        jobRef.addValueEventListener(jobL);

        myPropRef = db.child("proposals").child(jobId + "_" + uid);
        myPropL = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                proposalSent = s.exists();
                btnApply.setEnabled(!proposalSent);
                btnApply.setText(proposalSent ? "Proposal sent ✓" : "Submit a proposal");
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };
        myPropRef.addValueEventListener(myPropL);
    }

    private void render() {
        Ui.bindJob(findViewById(R.id.content), job);
        ((TextView) findViewById(R.id.tvSeller)).setText("Posted by " + Ui.nz(job.sellerName));
        boolean owner = uid.equals(job.sellerId);
        btnApply.setVisibility(owner ? View.GONE : View.VISIBLE);
        findViewById(R.id.ownerBox).setVisibility(owner ? View.VISIBLE : View.GONE);
        if (owner && !ownerListening) {
            ownerListening = true;
            setupOwner();
        }
    }

    // ---------- freelancer side ----------
    private void showProposalSheet() {
        BottomSheetDialog d = new BottomSheetDialog(this);
        View s = getLayoutInflater().inflate(R.layout.sheet_proposal, null);
        d.setContentView(s);
        Ui.blurBehind(d);
        EditText bid = s.findViewById(R.id.etBid), cover = s.findViewById(R.id.etCover);
        View send = s.findViewById(R.id.btnSubmit);
        Ui.press(send);
        send.setOnClickListener(v -> {
            String bt = bid.getText().toString().trim(), ct = cover.getText().toString().trim();
            if (bt.isEmpty() || ct.isEmpty() || job == null) {
                Toast.makeText(this, "Bid আর cover letter দিন", Toast.LENGTH_SHORT).show();
                return;
            }
            long amount;
            try { amount = Long.parseLong(bt); }
            catch (NumberFormatException ex) { Toast.makeText(this, "Bid সঠিক নয়", Toast.LENGTH_SHORT).show(); return; }
            Map<String, Object> m = new HashMap<>();
            m.put("jobId", jobId);
            m.put("jobTitle", job.title);
            m.put("freelancerId", uid);
            m.put("freelancerName", myName);
            m.put("sellerId", job.sellerId);
            m.put("sellerName", job.sellerName);
            m.put("cover", ct);
            m.put("bid", amount);
            m.put("status", "pending");
            m.put("timestamp", System.currentTimeMillis());
            myPropRef.setValue(m).addOnSuccessListener(x -> {
                jobRef.child("proposals").setValue(ServerValue.increment(1));
                Ui.pushAlert(job.sellerId, myName + " sent a proposal for \"" + job.title + "\"");
                d.dismiss();
                Toast.makeText(this, "Proposal পাঠানো হয়েছে", Toast.LENGTH_SHORT).show();
            });
        });
        d.show();
    }

    // ---------- owner (seller) side ----------
    private void setupOwner() {
        EditText invite = findViewById(R.id.etInvite);
        View btn = findViewById(R.id.btnInvite);
        Ui.press(btn);
        btn.setOnClickListener(v -> {
            String email = invite.getText().toString().trim();
            if (email.isEmpty()) return;
            db.child("users").orderByChild("email").equalTo(email)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot s) {
                        if (!s.hasChildren()) {
                            Toast.makeText(JobDetailActivity.this, "এই email এ কোনো user নেই", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        String target = s.getChildren().iterator().next().getKey();
                        db.child("invites").child(target).child(jobId).setValue(true);
                        Ui.pushAlert(target, "You were invited to \"" + job.title + "\"");
                        invite.setText("");
                        Toast.makeText(JobDetailActivity.this, "Invite পাঠানো হয়েছে", Toast.LENGTH_SHORT).show();
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {}
                });
        });

        propsRef = db.child("proposals");
        propsL = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                List<Proposal> list = new ArrayList<>();
                for (DataSnapshot d : s.getChildren()) {
                    Proposal p = d.getValue(Proposal.class);
                    if (p != null && jobId.equals(p.jobId)) { p.id = d.getKey(); list.add(p); }
                }
                Collections.sort(list, (a, c) -> Long.compare(c.timestamp, a.timestamp));
                propList.removeAllViews();
                noProps.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
                for (Proposal p : list) addProposalView(p);
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };
        propsRef.addValueEventListener(propsL);
    }

    private void addProposalView(Proposal p) {
        View v = getLayoutInflater().inflate(R.layout.item_received, propList, false);
        ((TextView) v.findViewById(R.id.tvName)).setText(Ui.nz(p.freelancerName));
        ((TextView) v.findViewById(R.id.tvBid)).setText("Bid: $" + p.bid);
        ((TextView) v.findViewById(R.id.tvCover)).setText(Ui.nz(p.cover));
        boolean pending = "pending".equals(p.status);
        v.findViewById(R.id.actions).setVisibility(pending ? View.VISIBLE : View.GONE);
        TextView st = v.findViewById(R.id.tvStatus);
        st.setVisibility(pending ? View.GONE : View.VISIBLE);
        st.setText(Ui.nz(p.status).toUpperCase());
        st.setTextColor(Ui.statusColor(p.status));
        Ui.press(v.findViewById(R.id.btnAccept));
        v.findViewById(R.id.btnAccept).setOnClickListener(x -> accept(p));
        v.findViewById(R.id.btnDecline).setOnClickListener(x -> decline(p));
        v.setOnClickListener(x -> Ui.open(this, new Intent(this, ChatActivity.class)
            .putExtra("chatId", p.id).putExtra("title", p.freelancerName)));
        propList.addView(v);
    }

    private void accept(Proposal p) {
        Map<String, Object> c = new HashMap<>();
        c.put("jobId", jobId);
        c.put("jobTitle", job.title);
        c.put("clientId", uid);
        c.put("clientName", Ui.nz(job.sellerName));
        c.put("freelancerId", p.freelancerId);
        c.put("freelancerName", p.freelancerName);
        c.put("price", p.bid);
        c.put("status", "active");
        c.put("timestamp", System.currentTimeMillis());
        Map<String, Object> up = new HashMap<>();
        up.put("proposals/" + p.id + "/status", "accepted");
        up.put("contracts/" + p.id, c);
        db.updateChildren(up);
        jobRef.child("spent").setValue(ServerValue.increment(p.bid));
        Ui.pushAlert(p.freelancerId, "Your proposal for \"" + job.title + "\" was accepted");
    }

    private void decline(Proposal p) {
        db.child("proposals").child(p.id).child("status").setValue("declined");
        Ui.pushAlert(p.freelancerId, "Your proposal for \"" + job.title + "\" was declined");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (jobRef != null && jobL != null) jobRef.removeEventListener(jobL);
        if (myPropRef != null && myPropL != null) myPropRef.removeEventListener(myPropL);
        if (propsRef != null && propsL != null) propsRef.removeEventListener(propsL);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.hold, R.anim.slide_out_right);
    }
}

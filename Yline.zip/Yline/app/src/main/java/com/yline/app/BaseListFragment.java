package com.yline.app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;

public abstract class BaseListFragment<T> extends Fragment {
    protected final List<T> items = new ArrayList<>();
    protected String uid;
    private RecyclerView rv;
    private TextView empty;
    private SimpleAdapter<T> adapter;
    private DatabaseReference ref;
    private ValueEventListener listener;

    protected abstract int itemLayout();
    protected abstract String emptyText();
    protected abstract DatabaseReference source();
    protected abstract void collect(DataSnapshot snap, List<T> out);
    protected abstract void bind(View v, T item);
    protected void onItemClick(T item) {}

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup c, @Nullable Bundle s) {
        View v = inf.inflate(R.layout.fragment_list, c, false);
        uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        rv = v.findViewById(R.id.rv);
        empty = v.findViewById(R.id.tvEmpty);
        empty.setText(emptyText());
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        rv.setLayoutAnimation(AnimationUtils.loadLayoutAnimation(getContext(), R.anim.layout_fall));
        adapter = new SimpleAdapter<>(itemLayout(), items, (view, item) -> {
            bind(view, item);
            Ui.press(view);
            view.setOnClickListener(x -> onItemClick(item));
        });
        rv.setAdapter(adapter);
        ref = source();
        listener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snap) {
                items.clear();
                collect(snap, items);
                adapter.notifyDataSetChanged();
                rv.scheduleLayoutAnimation();
                empty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };
        ref.addValueEventListener(listener);
        return v;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (ref != null && listener != null) ref.removeEventListener(listener);
    }
}

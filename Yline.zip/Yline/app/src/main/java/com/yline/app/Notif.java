package com.yline.app;

public class Notif {
    public String id, text;
    public long time;
    public boolean read;
    public Notif() {}
}

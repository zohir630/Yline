package com.yline.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.os.Build;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.annotation.NonNull;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.HashMap;
import java.util.Map;

public class Ui {
    public static String nz(String s) { return s == null ? "" : s; }

    public static String timeAgo(long ts) {
        long m = (System.currentTimeMillis() - ts) / 60000;
        if (m < 1) return "just now";
        if (m < 60) return m + (m == 1 ? " minute ago" : " minutes ago");
        long h = m / 60;
        if (h < 24) return h + (h == 1 ? " hour ago" : " hours ago");
        long d = h / 24;
        return d + (d == 1 ? " day ago" : " days ago");
    }

    public static String bucket(long n) {
        if (n < 5) return "Less than 5";
        if (n < 10) return "5 to 10";
        if (n < 15) return "10 to 15";
        if (n < 20) return "15 to 20";
        if (n < 50) return "20 to 50";
        return "50+";
    }

    public static String initial(String name) {
        if (name == null || name.trim().isEmpty()) return "?";
        return name.trim().substring(0, 1).toUpperCase();
    }

    public static int statusColor(String s) {
        if ("accepted".equals(s) || "active".equals(s)) return 0xFF14A800;
        if ("declined".equals(s)) return 0xFFD93025;
        return 0xFFF5A623;
    }

    public static CharSequence stars(double rating) {
        SpannableString s = new SpannableString("★★★★★");
        int n = (int) Math.round(rating);
        if (n < 0) n = 0;
        if (n > 5) n = 5;
        if (n > 0) s.setSpan(new ForegroundColorSpan(0xFF14A800), 0, n, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (n < 5) s.setSpan(new ForegroundColorSpan(0xFFBDBDBD), n, 5, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        return s;
    }

    /** Fills the shared job views (same ids in item_job and activity_job_detail). */
    public static void bindJob(View v, Job j) {
        ((TextView) v.findViewById(R.id.tvMeta)).setText(
            "Posted " + timeAgo(j.timestamp) + "  •  Proposals: " + bucket(j.proposals));
        ((TextView) v.findViewById(R.id.tvTitle)).setText(nz(j.title));
        String price = "hourly".equals(j.type)
            ? "Hourly: $" + j.minPrice + "-$" + j.maxPrice
            : "Fixed-price: $" + j.minPrice;
        String hrs = nz(j.hours).isEmpty() ? "" : ", " + j.hours;
        ((TextView) v.findViewById(R.id.tvInfo)).setText(
            price + " - " + nz(j.level) + " - Est. Time: " + nz(j.duration) + hrs);
        ((TextView) v.findViewById(R.id.tvDesc)).setText(nz(j.description));
        TextView skill = v.findViewById(R.id.tvSkill);
        skill.setText(nz(j.skill));
        skill.setVisibility(nz(j.skill).isEmpty() ? View.GONE : View.VISIBLE);
        ((android.widget.ImageView) v.findViewById(R.id.ivVerified)).setImageResource(
            j.paymentVerified ? R.drawable.ic_verified_green : R.drawable.ic_verified);
        ((TextView) v.findViewById(R.id.tvPayment)).setText(
            j.paymentVerified ? "Payment verified" : "Payment unverified");
        ((TextView) v.findViewById(R.id.tvStars)).setText(stars(j.rating));
        ((TextView) v.findViewById(R.id.tvSpent)).setText("$" + j.spent + " spent");
        ((TextView) v.findViewById(R.id.tvLocation)).setText(nz(j.location));
    }

    // ---------- animation & blur ----------
    @SuppressLint("ClickableViewAccessibility")
    public static void press(View v) {
        v.setOnTouchListener((view, e) -> {
            int a = e.getAction();
            if (a == MotionEvent.ACTION_DOWN) {
                view.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start();
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                view.animate().scaleX(1f).scaleY(1f).setDuration(150).start();
            }
            return false;
        });
    }

    public static void bounce(View v) {
        v.animate().scaleX(1.35f).scaleY(1.35f).setDuration(110).withEndAction(
            () -> v.animate().scaleX(1f).scaleY(1f).setDuration(160).start()).start();
    }

    public static void enter(View v) {
        v.setAlpha(0f);
        v.setTranslationY(140f);
        v.animate().alpha(1f).translationY(0f).setDuration(600)
            .setInterpolator(new DecelerateInterpolator(2f)).start();
    }

    public static void floatBlob(View v, float dx, float dy, long dur) {
        ObjectAnimator x = ObjectAnimator.ofFloat(v, "translationX", 0f, dx);
        ObjectAnimator y = ObjectAnimator.ofFloat(v, "translationY", 0f, dy);
        for (ObjectAnimator a : new ObjectAnimator[]{x, y}) {
            a.setDuration(dur);
            a.setRepeatCount(ValueAnimator.INFINITE);
            a.setRepeatMode(ValueAnimator.REVERSE);
            a.start();
        }
    }

    public static void blur(View v, float radius) {
        if (Build.VERSION.SDK_INT >= 31) {
            v.setRenderEffect(RenderEffect.createBlurEffect(radius, radius, Shader.TileMode.CLAMP));
        }
    }

    public static void blurBehind(Dialog d) {
        Window w = d.getWindow();
        if (w == null) return;
        w.setDimAmount(0.35f);
        if (Build.VERSION.SDK_INT >= 31) {
            w.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
            WindowManager.LayoutParams p = w.getAttributes();
            p.setBlurBehindRadius(40);
            w.setAttributes(p);
        }
    }

    // ---------- navigation ----------
    public static void open(Activity a, Intent i) {
        a.startActivity(i);
        a.overridePendingTransition(R.anim.slide_in_right, R.anim.hold);
    }

    public static void toMain(Activity a) {
        a.startActivity(new Intent(a, MainActivity.class));
        a.finishAffinity();
        a.overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    public static void toast(Activity a, String m) { Toast.makeText(a, m, Toast.LENGTH_LONG).show(); }

    // ---------- data ----------
    public static void pushAlert(String uid, String text) {
        Map<String, Object> m = new HashMap<>();
        m.put("text", text);
        m.put("time", System.currentTimeMillis());
        m.put("read", false);
        FirebaseDatabase.getInstance().getReference("notifications").child(uid).push().setValue(m);
    }

    /** After any successful login: make sure a profile (with role) exists, then open Main. */
    public static void finishLogin(Activity a) {
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u == null) return;
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("users").child(u.getUid());
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                if (s.exists()) { toMain(a); return; }
                AlertDialog d = new AlertDialog.Builder(a)
                    .setTitle("Account type বেছে নিন")
                    .setCancelable(false)
                    .setItems(new String[]{"Regular", "Seller"}, (dlg, which) -> {
                        Map<String, Object> m = new HashMap<>();
                        String name = u.getDisplayName() != null ? u.getDisplayName() : nz(u.getEmail());
                        m.put("name", name);
                        m.put("email", nz(u.getEmail()));
                        m.put("role", which == 1 ? "seller" : "regular");
                        ref.setValue(m).addOnCompleteListener(t -> toMain(a));
                    }).create();
                blurBehind(d);
                d.show();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) { toast(a, e.getMessage()); }
        });
    }
}

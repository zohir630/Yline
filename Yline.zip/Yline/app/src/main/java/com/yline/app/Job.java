package com.yline.app;

public class Job {
    public String id, title, description, type, level, duration, hours, skill, location, sellerId, sellerName;
    public long minPrice, maxPrice, spent, proposals, timestamp;
    public boolean paymentVerified;
    public double rating;
    public Job() {}
}

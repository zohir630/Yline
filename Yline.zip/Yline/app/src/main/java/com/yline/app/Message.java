package com.yline.app;

public class Message {
    public String sender, name, text;
    public long time;
    public Message() {}
}

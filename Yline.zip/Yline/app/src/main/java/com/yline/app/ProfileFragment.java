package com.yline.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import com.google.firebase.auth.*;
import com.google.firebase.database.*;

public class ProfileFragment extends Fragment {
    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup c, @Nullable Bundle s) {
        View v = inf.inflate(R.layout.fragment_profile, c, false);
        TextView name = v.findViewById(R.id.tvName), email = v.findViewById(R.id.tvEmail), role = v.findViewById(R.id.tvRole);
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u != null) {
            email.setText(u.getEmail());
            FirebaseDatabase.getInstance().getReference("users").child(u.getUid())
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot d) {
                        name.setText(d.child("name").getValue(String.class));
                        String r = d.child("role").getValue(String.class);
                        role.setText("seller".equals(r) ? "Seller account" : "Regular account");
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {}
                });
        }
        v.findViewById(R.id.btnLogout).setOnClickListener(b -> {
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(getActivity(), LoginActivity.class));
            requireActivity().finishAffinity();
        });
        return v;
    }
}

package com.yline.app;

public class Contract {
    public String id, jobId, jobTitle, clientId, clientName, freelancerId, freelancerName, status;
    public long price, timestamp;
    public Contract() {}
}

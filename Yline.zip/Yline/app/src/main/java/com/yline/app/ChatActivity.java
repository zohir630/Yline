package com.yline.app;

import android.os.Bundle;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatActivity extends AppCompatActivity {
    private final List<Message> list = new ArrayList<>();
    private SimpleAdapter<Message> adapter;
    private RecyclerView rv;
    private DatabaseReference ref;
    private ChildEventListener cl;
    private String uid, myName = "User";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_chat);
        uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        String chatId = getIntent().getStringExtra("chatId");
        ((TextView) findViewById(R.id.tvTitle)).setText(Ui.nz(getIntent().getStringExtra("title")));
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        FirebaseDatabase.getInstance().getReference("users").child(uid).child("name")
            .addListenerForSingleValueEvent(new ValueEventListener() {
                @Override public void onDataChange(@NonNull DataSnapshot s) {
                    String n = s.getValue(String.class);
                    if (n != null) myName = n;
                }
                @Override public void onCancelled(@NonNull DatabaseError e) {}
            });

        rv = findViewById(R.id.rv);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new SimpleAdapter<>(R.layout.item_msg, list, (v, m) -> {
            TextView t = v.findViewById(R.id.tvMsg);
            boolean me = uid.equals(m.sender);
            t.setText(Ui.nz(m.text));
            t.setBackgroundResource(me ? R.drawable.bg_bubble_me : R.drawable.bg_bubble_other);
            t.setTextColor(me ? 0xFFFFFFFF : 0xFF111111);
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) t.getLayoutParams();
            lp.gravity = me ? Gravity.END : Gravity.START;
            t.setLayoutParams(lp);
        });
        rv.setAdapter(adapter);

        ref = FirebaseDatabase.getInstance().getReference("chats").child(chatId);
        cl = new ChildEventListener() {
            @Override public void onChildAdded(@NonNull DataSnapshot s, @Nullable String prev) {
                Message m = s.getValue(Message.class);
                if (m == null) return;
                list.add(m);
                adapter.notifyItemInserted(list.size() - 1);
                rv.smoothScrollToPosition(list.size() - 1);
            }
            @Override public void onChildChanged(@NonNull DataSnapshot s, @Nullable String prev) {}
            @Override public void onChildRemoved(@NonNull DataSnapshot s) {}
            @Override public void onChildMoved(@NonNull DataSnapshot s, @Nullable String prev) {}
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };
        ref.addChildEventListener(cl);

        EditText input = findViewById(R.id.etMsg);
        Ui.press(findViewById(R.id.btnSend));
        findViewById(R.id.btnSend).setOnClickListener(v -> {
            String text = input.getText().toString().trim();
            if (text.isEmpty()) return;
            Map<String, Object> m = new HashMap<>();
            m.put("sender", uid);
            m.put("name", myName);
            m.put("text", text);
            m.put("time", System.currentTimeMillis());
            ref.push().setValue(m);
            input.setText("");
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (ref != null && cl != null) ref.removeEventListener(cl);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.hold, R.anim.slide_out_right);
    }
}

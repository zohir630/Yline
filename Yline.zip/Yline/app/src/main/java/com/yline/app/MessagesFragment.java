package com.yline.app;

import android.content.Intent;
import android.view.View;
import android.widget.TextView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.Collections;
import java.util.List;

public class MessagesFragment extends BaseListFragment<Proposal> {
    @Override protected int itemLayout() { return R.layout.item_row; }
    @Override protected String emptyText() { return "Proposal পাঠালে বা পেলে এখানে chat দেখা যাবে"; }
    @Override protected DatabaseReference source() { return FirebaseDatabase.getInstance().getReference("proposals"); }

    @Override
    protected void collect(DataSnapshot snap, List<Proposal> out) {
        for (DataSnapshot d : snap.getChildren()) {
            Proposal p = d.getValue(Proposal.class);
            if (p != null && (uid.equals(p.freelancerId) || uid.equals(p.sellerId))) {
                p.id = d.getKey();
                out.add(p);
            }
        }
        Collections.sort(out, (a, b) -> Long.compare(b.timestamp, a.timestamp));
    }

    private String other(Proposal p) {
        return uid.equals(p.sellerId) ? Ui.nz(p.freelancerName) : Ui.nz(p.sellerName);
    }

    @Override
    protected void bind(View v, Proposal p) {
        ((TextView) v.findViewById(R.id.tvTitle)).setText(other(p));
        ((TextView) v.findViewById(R.id.tvSub)).setText(Ui.nz(p.jobTitle));
        ((TextView) v.findViewById(R.id.tvTime)).setText(Ui.timeAgo(p.timestamp));
    }

    @Override
    protected void onItemClick(Proposal p) {
        Intent i = new Intent(getActivity(), ChatActivity.class)
            .putExtra("chatId", p.id).putExtra("title", other(p));
        Ui.open(requireActivity(), i);
    }
}

package com.yline.app;

import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import com.google.firebase.auth.*;
import com.google.firebase.database.*;
import java.util.*;

public class JobFragment extends Fragment {
    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup c, @Nullable Bundle s) {
        View v = inf.inflate(R.layout.fragment_job, c, false);
        View form = v.findViewById(R.id.formBox), info = v.findViewById(R.id.tvInfo);
        EditText t = v.findViewById(R.id.etTitle), d = v.findViewById(R.id.etDesc), pr = v.findViewById(R.id.etPrice);
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u == null) return v;
        final String[] sellerName = {""};
        FirebaseDatabase.getInstance().getReference("users").child(u.getUid())
            .addListenerForSingleValueEvent(new ValueEventListener() {
                @Override public void onDataChange(@NonNull DataSnapshot s) {
                    boolean seller = "seller".equals(s.child("role").getValue(String.class));
                    sellerName[0] = String.valueOf(s.child("name").getValue(String.class));
                    form.setVisibility(seller ? View.VISIBLE : View.GONE);
                    info.setVisibility(seller ? View.GONE : View.VISIBLE);
                }
                @Override public void onCancelled(@NonNull DatabaseError e) {}
            });
        v.findViewById(R.id.btnPost).setOnClickListener(b -> {
            String title = t.getText().toString().trim(), desc = d.getText().toString().trim(), price = pr.getText().toString().trim();
            if (title.isEmpty() || desc.isEmpty() || price.isEmpty()) {
                Toast.makeText(getContext(), "সব ঘর পূরণ করুন", Toast.LENGTH_SHORT).show();
                return;
            }
            Map<String, Object> post = new HashMap<>();
            post.put("title", title); post.put("description", desc);
            post.put("price", Long.parseLong(price));
            post.put("sellerId", u.getUid()); post.put("sellerName", sellerName[0]);
            post.put("timestamp", System.currentTimeMillis());
            FirebaseDatabase.getInstance().getReference("posts").push().setValue(post)
                .addOnSuccessListener(x -> {
                    t.setText(""); d.setText(""); pr.setText("");
                    Toast.makeText(getContext(), "Posted!", Toast.LENGTH_SHORT).show();
                });
        });
        return v;
    }
}

package com.yline.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.badge.BadgeDrawable;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    private BottomNavigationView nav;
    private DatabaseReference nameRef, alertRef;
    private ValueEventListener nameL, alertL;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }
        setContentView(R.layout.activity_main);
        TextView title = findViewById(R.id.tvTitle), avatar = findViewById(R.id.avatar);
        nav = findViewById(R.id.bottomNav);

        Ui.press(avatar);
        avatar.setOnClickListener(v -> Ui.open(this, new Intent(this, ProfileActivity.class)));

        DatabaseReference db = FirebaseDatabase.getInstance().getReference();
        nameRef = db.child("users").child(u.getUid()).child("name");
        nameL = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                avatar.setText(Ui.initial(s.getValue(String.class)));
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };
        nameRef.addValueEventListener(nameL);

        alertRef = db.child("notifications").child(u.getUid());
        alertL = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                int n = 0;
                for (DataSnapshot d : s.getChildren()) {
                    Boolean read = d.child("read").getValue(Boolean.class);
                    if (read == null || !read) n++;
                }
                if (n > 0) {
                    BadgeDrawable bd = nav.getOrCreateBadge(R.id.nav_alerts);
                    bd.setNumber(n);
                    bd.setVisible(true);
                } else {
                    nav.removeBadge(R.id.nav_alerts);
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };
        alertRef.addValueEventListener(alertL);

        nav.setOnItemSelectedListener(item -> {
            Fragment f;
            String t;
            int id = item.getItemId();
            if (id == R.id.nav_proposals) { f = new ProposalsFragment(); t = "Proposals"; }
            else if (id == R.id.nav_contracts) { f = new ContractsFragment(); t = "Contracts"; }
            else if (id == R.id.nav_messages) { f = new MessagesFragment(); t = "Messages"; }
            else if (id == R.id.nav_alerts) { f = new AlertsFragment(); t = "Alerts"; }
            else { f = new JobsFragment(); t = "Jobs"; }
            title.setText(t);
            title.setAlpha(0f);
            title.animate().alpha(1f).setDuration(250).start();
            getSupportFragmentManager().beginTransaction()
                .setCustomAnimations(R.anim.fade_in, R.anim.fade_out)
                .replace(R.id.container, f).commit();
            return true;
        });
        if (b == null) nav.setSelectedItemId(R.id.nav_jobs);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (nameRef != null && nameL != null) nameRef.removeEventListener(nameL);
        if (alertRef != null && alertL != null) alertRef.removeEventListener(alertL);
    }
}

package com.yline.app;

public class Post {
    public String id, title, description, sellerId, sellerName;
    public long price, timestamp;
    public Post() {}
}

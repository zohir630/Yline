package com.yline.app;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.HashMap;
import java.util.Map;

public class PostJobActivity extends AppCompatActivity {
    private String uid, sellerName = "";
    private boolean isSeller = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_post_job);
        Ui.enter(findViewById(R.id.form));
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference db = FirebaseDatabase.getInstance().getReference();

        // only seller accounts may post
        db.child("users").child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                isSeller = "seller".equals(s.child("role").getValue(String.class));
                String n = s.child("name").getValue(String.class);
                if (n != null) sellerName = n;
                if (!isSeller) {
                    Toast.makeText(PostJobActivity.this, "শুধু Seller account থেকে post করা যায়", Toast.LENGTH_LONG).show();
                    finish();
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        });

        Spinner level = findViewById(R.id.spLevel), duration = findViewById(R.id.spDuration);
        ArrayAdapter<CharSequence> la = ArrayAdapter.createFromResource(this, R.array.levels, android.R.layout.simple_spinner_item);
        la.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        level.setAdapter(la);
        level.setSelection(1);
        ArrayAdapter<CharSequence> da = ArrayAdapter.createFromResource(this, R.array.durations, android.R.layout.simple_spinner_item);
        da.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        duration.setAdapter(da);

        EditText title = findViewById(R.id.etTitle), desc = findViewById(R.id.etDesc),
            min = findViewById(R.id.etMin), max = findViewById(R.id.etMax),
            hours = findViewById(R.id.etHours), skill = findViewById(R.id.etSkill),
            loc = findViewById(R.id.etLocation);
        RadioGroup type = findViewById(R.id.rgType);
        Switch verified = findViewById(R.id.swVerified);
        type.setOnCheckedChangeListener((g, id) ->
            max.setVisibility(id == R.id.rbFixed ? View.GONE : View.VISIBLE));

        View post = findViewById(R.id.btnPost);
        Ui.press(post);
        post.setOnClickListener(v -> {
            if (!isSeller) return;
            String t = title.getText().toString().trim(), d = desc.getText().toString().trim();
            boolean hourly = type.getCheckedRadioButtonId() == R.id.rbHourly;
            if (t.isEmpty() || d.isEmpty() || min.getText().toString().trim().isEmpty()) {
                Toast.makeText(this, "Title, description আর price দিন", Toast.LENGTH_SHORT).show();
                return;
            }
            long lo, hi;
            try {
                lo = Long.parseLong(min.getText().toString().trim());
                String mx = max.getText().toString().trim();
                hi = (hourly && !mx.isEmpty()) ? Long.parseLong(mx) : lo;
            } catch (NumberFormatException ex) {
                Toast.makeText(this, "Price সঠিক নয়", Toast.LENGTH_SHORT).show();
                return;
            }
            Map<String, Object> m = new HashMap<>();
            m.put("title", t);
            m.put("description", d);
            m.put("type", hourly ? "hourly" : "fixed");
            m.put("minPrice", lo);
            m.put("maxPrice", hi);
            m.put("level", level.getSelectedItem().toString());
            m.put("duration", duration.getSelectedItem().toString());
            m.put("hours", hours.getText().toString().trim());
            m.put("skill", skill.getText().toString().trim());
            m.put("location", loc.getText().toString().trim());
            m.put("sellerId", uid);
            m.put("sellerName", sellerName);
            m.put("paymentVerified", verified.isChecked());
            m.put("spent", 0L);
            m.put("rating", 0);
            m.put("proposals", 0L);
            m.put("timestamp", System.currentTimeMillis());
            db.child("jobs").push().setValue(m).addOnSuccessListener(x -> {
                Toast.makeText(this, "Job post হয়েছে", Toast.LENGTH_SHORT).show();
                finish();
            });
        });
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.hold, R.anim.slide_out_right);
    }
}

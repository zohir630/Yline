package com.yline.app;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ProfileActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_profile);
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        Ui.enter(findViewById(R.id.box));
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u == null) { finish(); return; }
        TextView name = findViewById(R.id.tvName), email = findViewById(R.id.tvEmail),
            role = findViewById(R.id.tvRole), avatar = findViewById(R.id.tvAvatar);
        email.setText(Ui.nz(u.getEmail()));
        FirebaseDatabase.getInstance().getReference("users").child(u.getUid())
            .addListenerForSingleValueEvent(new ValueEventListener() {
                @Override public void onDataChange(@NonNull DataSnapshot d) {
                    String n = d.child("name").getValue(String.class);
                    name.setText(Ui.nz(n));
                    avatar.setText(Ui.initial(n));
                    boolean seller = "seller".equals(d.child("role").getValue(String.class));
                    role.setText(seller ? "Seller account" : "Regular account");
                    role.setBackgroundTintList(ColorStateList.valueOf(seller ? 0xFF14A800 : 0xFF5B6770));
                }
                @Override public void onCancelled(@NonNull DatabaseError e) {}
            });
        Ui.press(findViewById(R.id.btnLogout));
        findViewById(R.id.btnLogout).setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            GoogleSignIn.getClient(this, GoogleSignInOptions.DEFAULT_SIGN_IN).signOut();
            startActivity(new Intent(this, LoginActivity.class));
            finishAffinity();
        });
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.hold, R.anim.slide_out_right);
    }
}

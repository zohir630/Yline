package com.yline.app;

public class Proposal {
    public String id, jobId, jobTitle, freelancerId, freelancerName, sellerId, sellerName, cover, status;
    public long bid, timestamp;
    public Proposal() {}
}

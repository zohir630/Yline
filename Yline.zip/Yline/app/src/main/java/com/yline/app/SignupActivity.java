package com.yline.app;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import java.util.HashMap;
import java.util.Map;

public class SignupActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_signup);
        Ui.blur(findViewById(R.id.blob1), 90f);
        Ui.blur(findViewById(R.id.blob2), 90f);
        Ui.floatBlob(findViewById(R.id.blob1), -70f, 50f, 5500);
        Ui.floatBlob(findViewById(R.id.blob2), 60f, -60f, 6500);
        Ui.enter(findViewById(R.id.card));

        EditText name = findViewById(R.id.etName), email = findViewById(R.id.etEmail), pass = findViewById(R.id.etPassword);
        RadioGroup rg = findViewById(R.id.rgRole);
        View btn = findViewById(R.id.btnSignup);
        Ui.press(btn);
        btn.setOnClickListener(v -> {
            String n = name.getText().toString().trim(), e = email.getText().toString().trim(), p = pass.getText().toString();
            if (n.isEmpty() || e.isEmpty() || p.length() < 6) {
                Ui.toast(this, "সব ঘর পূরণ করুন (password কমপক্ষে ৬ অক্ষর)");
                return;
            }
            String role = rg.getCheckedRadioButtonId() == R.id.rbSeller ? "seller" : "regular";
            FirebaseAuth.getInstance().createUserWithEmailAndPassword(e, p).addOnCompleteListener(t -> {
                if (!t.isSuccessful()) {
                    Ui.toast(this, t.getException() != null ? t.getException().getMessage() : "Sign up failed");
                    return;
                }
                String uid = t.getResult().getUser().getUid();
                Map<String, Object> u = new HashMap<>();
                u.put("name", n);
                u.put("email", e);
                u.put("role", role);
                FirebaseDatabase.getInstance().getReference("users").child(uid).setValue(u)
                    .addOnCompleteListener(x -> Ui.toMain(this));
            });
        });
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.hold, R.anim.slide_out_right);
    }
}

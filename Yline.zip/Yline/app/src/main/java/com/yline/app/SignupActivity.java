package com.yline.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import java.util.HashMap;
import java.util.Map;

public class SignupActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_signup);
        EditText name = findViewById(R.id.etName), email = findViewById(R.id.etEmail), pass = findViewById(R.id.etPassword);
        RadioGroup rg = findViewById(R.id.rgRole);
        findViewById(R.id.btnSignup).setOnClickListener(v -> {
            String n = name.getText().toString().trim(), e = email.getText().toString().trim(), p = pass.getText().toString();
            if (n.isEmpty() || e.isEmpty() || p.length() < 6) { toast("সব ঘর পূরণ করুন (password কমপক্ষে ৬ অক্ষর)"); return; }
            String role = rg.getCheckedRadioButtonId() == R.id.rbSeller ? "seller" : "regular";
            FirebaseAuth.getInstance().createUserWithEmailAndPassword(e, p).addOnCompleteListener(t -> {
                if (!t.isSuccessful()) {
                    toast(t.getException() != null ? t.getException().getMessage() : "Sign up failed");
                    return;
                }
                String uid = t.getResult().getUser().getUid();
                Map<String, Object> u = new HashMap<>();
                u.put("name", n); u.put("email", e); u.put("role", role);
                FirebaseDatabase.getInstance().getReference("users").child(uid).setValue(u)
                    .addOnCompleteListener(x -> {
                        startActivity(new Intent(this, MainActivity.class));
                        finishAffinity();
                    });
            });
        });
    }
    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_LONG).show(); }
}

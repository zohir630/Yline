package com.yline.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() != null) { goMain(); return; }
        setContentView(R.layout.activity_login);
        EditText email = findViewById(R.id.etEmail), pass = findViewById(R.id.etPassword);
        findViewById(R.id.btnLogin).setOnClickListener(v -> {
            String e = email.getText().toString().trim(), p = pass.getText().toString();
            if (e.isEmpty() || p.isEmpty()) { toast("Email ও password দিন"); return; }
            auth.signInWithEmailAndPassword(e, p).addOnCompleteListener(t -> {
                if (t.isSuccessful()) goMain();
                else toast(t.getException() != null ? t.getException().getMessage() : "Login failed");
            });
        });
        findViewById(R.id.tvSignup).setOnClickListener(v ->
            startActivity(new Intent(this, SignupActivity.class)));
    }

    private void goMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_LONG).show(); }
}

package com.yline.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;

public class LoginActivity extends AppCompatActivity {
    private FirebaseAuth auth;
    private GoogleSignInClient gsc;

    private final ActivityResultLauncher<Intent> googleLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), r -> {
            try {
                GoogleSignInAccount acc = GoogleSignIn.getSignedInAccountFromIntent(r.getData())
                    .getResult(ApiException.class);
                AuthCredential cred = GoogleAuthProvider.getCredential(acc.getIdToken(), null);
                auth.signInWithCredential(cred).addOnCompleteListener(t -> {
                    if (t.isSuccessful()) Ui.finishLogin(this);
                    else Ui.toast(this, t.getException() != null ? t.getException().getMessage() : "Google login failed");
                });
            } catch (ApiException e) {
                Ui.toast(this, "Google sign-in failed (code " + e.getStatusCode() + "). SHA-1 Firebase এ দিয়েছেন কিনা দেখুন।");
            }
        });

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() != null) { Ui.finishLogin(this); return; }
        setContentView(R.layout.activity_login);

        View blob1 = findViewById(R.id.blob1), blob2 = findViewById(R.id.blob2), card = findViewById(R.id.card);
        Ui.blur(blob1, 90f);
        Ui.blur(blob2, 90f);
        Ui.floatBlob(blob1, 70f, 50f, 5000);
        Ui.floatBlob(blob2, -60f, -70f, 6000);
        Ui.enter(card);

        EditText email = findViewById(R.id.etEmail), pass = findViewById(R.id.etPassword);
        View login = findViewById(R.id.btnLogin), google = findViewById(R.id.btnGoogle);
        Ui.press(login);
        Ui.press(google);
        login.setOnClickListener(v -> {
            String e = email.getText().toString().trim(), p = pass.getText().toString();
            if (e.isEmpty() || p.isEmpty()) { Ui.toast(this, "Email ও password দিন"); return; }
            auth.signInWithEmailAndPassword(e, p).addOnCompleteListener(t -> {
                if (t.isSuccessful()) Ui.finishLogin(this);
                else Ui.toast(this, t.getException() != null ? t.getException().getMessage() : "Login failed");
            });
        });

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.web_client_id))
            .requestEmail()
            .build();
        gsc = GoogleSignIn.getClient(this, gso);
        google.setOnClickListener(v ->
            gsc.signOut().addOnCompleteListener(t -> googleLauncher.launch(gsc.getSignInIntent())));

        findViewById(R.id.tvSignup).setOnClickListener(v ->
            Ui.open(this, new Intent(this, SignupActivity.class)));
    }
}

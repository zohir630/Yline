package com.yline.app;

import android.view.View;
import android.widget.TextView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.Collections;
import java.util.List;

public class AlertsFragment extends BaseListFragment<Notif> {
    @Override protected int itemLayout() { return R.layout.item_row; }
    @Override protected String emptyText() { return "কোনো alert নেই"; }
    @Override protected DatabaseReference source() {
        return FirebaseDatabase.getInstance().getReference("notifications").child(uid);
    }

    @Override
    protected void collect(DataSnapshot snap, List<Notif> out) {
        for (DataSnapshot d : snap.getChildren()) {
            Notif n = d.getValue(Notif.class);
            if (n != null) { n.id = d.getKey(); out.add(n); }
        }
        Collections.sort(out, (a, b) -> Long.compare(b.time, a.time));
    }

    @Override
    protected void bind(View v, Notif n) {
        ((TextView) v.findViewById(R.id.tvTitle)).setText(Ui.nz(n.text));
        v.findViewById(R.id.tvSub).setVisibility(View.GONE);
        ((TextView) v.findViewById(R.id.tvTime)).setText(Ui.timeAgo(n.time));
        v.findViewById(R.id.dot).setVisibility(n.read ? View.GONE : View.VISIBLE);
    }

    @Override
    public void onDestroyView() {
        // mark everything as read when leaving the Alerts tab
        DatabaseReference base = FirebaseDatabase.getInstance().getReference("notifications").child(uid);
        for (Notif n : items) {
            if (!n.read && n.id != null) base.child(n.id).child("read").setValue(true);
        }
        super.onDestroyView();
    }
}

package com.yline.app;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.VH> {
    private final List<Post> items;
    public PostAdapter(List<Post> items) { this.items = items; }

    static class VH extends RecyclerView.ViewHolder {
        TextView title, desc, price, seller;
        VH(View v) {
            super(v);
            title = v.findViewById(R.id.tvTitle);
            desc = v.findViewById(R.id.tvDesc);
            price = v.findViewById(R.id.tvPrice);
            seller = v.findViewById(R.id.tvSeller);
        }
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
        return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_post, p, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int i) {
        Post p = items.get(i);
        h.title.setText(p.title);
        h.desc.setText(p.description);
        h.price.setText("$" + p.price);
        h.seller.setText("by " + p.sellerName);
    }

    @Override public int getItemCount() { return items.size(); }
}

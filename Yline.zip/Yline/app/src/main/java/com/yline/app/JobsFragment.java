package com.yline.app;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class JobsFragment extends Fragment {
    private final List<Job> all = new ArrayList<>();
    private final List<Job> shown = new ArrayList<>();
    private final Set<String> saved = new HashSet<>();
    private final Set<String> hidden = new HashSet<>();
    private final Set<String> invited = new HashSet<>();
    private boolean savedOnly = false;
    private int tab = 0;
    private String query = "";
    private SimpleAdapter<Job> adapter;
    private RecyclerView rv;
    private TextView empty;
    private String uid;
    private DatabaseReference root;
    private final List<DatabaseReference> refs = new ArrayList<>();
    private final List<ValueEventListener> ls = new ArrayList<>();

    private void listen(DatabaseReference r, ValueEventListener l) {
        r.addValueEventListener(l);
        refs.add(r);
        ls.add(l);
    }

    private ValueEventListener keys(Set<String> target) {
        return new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                target.clear();
                for (DataSnapshot d : s.getChildren()) target.add(d.getKey());
                apply();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        };
    }

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup c, @Nullable Bundle s) {
        View v = inf.inflate(R.layout.fragment_jobs, c, false);
        uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        root = FirebaseDatabase.getInstance().getReference();
        rv = v.findViewById(R.id.rv);
        empty = v.findViewById(R.id.tvEmpty);
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        rv.setLayoutAnimation(AnimationUtils.loadLayoutAnimation(getContext(), R.anim.layout_fall));
        adapter = new SimpleAdapter<>(R.layout.item_job, shown, this::bindItem);
        rv.setAdapter(adapter);

        EditText et = v.findViewById(R.id.etSearch);
        et.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence a, int b, int c2, int d) {}
            @Override public void onTextChanged(CharSequence a, int b, int c2, int d) {}
            @Override public void afterTextChanged(Editable e) {
                query = e.toString().trim().toLowerCase();
                apply();
            }
        });

        ImageButton btnSaved = v.findViewById(R.id.btnSavedFilter);
        Ui.press(btnSaved);
        btnSaved.setOnClickListener(x -> {
            savedOnly = !savedOnly;
            btnSaved.setBackgroundResource(savedOnly ? R.drawable.bg_circle_green : R.drawable.bg_circle_green_stroke);
            btnSaved.setImageResource(savedOnly ? R.drawable.ic_heart_white : R.drawable.ic_heart);
            Ui.bounce(btnSaved);
            apply();
        });

        TabLayout tabs = v.findViewById(R.id.tabs);
        tabs.addTab(tabs.newTab().setText("Best matches"));
        tabs.addTab(tabs.newTab().setText("Most recent"));
        tabs.addTab(tabs.newTab().setText("Invites"));
        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override public void onTabSelected(TabLayout.Tab t) { tab = t.getPosition(); apply(); }
            @Override public void onTabUnselected(TabLayout.Tab t) {}
            @Override public void onTabReselected(TabLayout.Tab t) {}
        });

        // only sellers can post
        ExtendedFloatingActionButton fab = v.findViewById(R.id.fabPost);
        fab.setOnClickListener(x -> Ui.open(requireActivity(), new Intent(getActivity(), PostJobActivity.class)));
        root.child("users").child(uid).child("role").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot d) {
                if ("seller".equals(d.getValue(String.class))) fab.show();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        });

        listen(root.child("jobs"), new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snap) {
                all.clear();
                for (DataSnapshot d : snap.getChildren()) {
                    Job j = d.getValue(Job.class);
                    if (j != null) { j.id = d.getKey(); all.add(j); }
                }
                apply();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        });
        listen(root.child("userdata").child(uid).child("saved"), keys(saved));
        listen(root.child("userdata").child(uid).child("hidden"), keys(hidden));
        listen(root.child("invites").child(uid), keys(invited));
        return v;
    }

    private void apply() {
        if (rv == null) return;
        shown.clear();
        for (Job j : all) {
            if (hidden.contains(j.id)) continue;
            if (savedOnly && !saved.contains(j.id)) continue;
            if (tab == 2 && !invited.contains(j.id)) continue;
            if (!query.isEmpty()) {
                String hay = (Ui.nz(j.title) + " " + Ui.nz(j.description) + " " + Ui.nz(j.skill)).toLowerCase();
                if (!hay.contains(query)) continue;
            }
            shown.add(j);
        }
        if (tab == 0) {
            Collections.sort(shown, (a, b) -> {
                if (a.paymentVerified != b.paymentVerified) return a.paymentVerified ? -1 : 1;
                return Long.compare(b.timestamp, a.timestamp);
            });
        } else {
            Collections.sort(shown, (a, b) -> Long.compare(b.timestamp, a.timestamp));
        }
        adapter.notifyDataSetChanged();
        rv.scheduleLayoutAnimation();
        empty.setText(tab == 2 ? "কোনো invite নেই" : "কোনো job পাওয়া যায়নি");
        empty.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void bindItem(View v, Job j) {
        Ui.bindJob(v, j);
        TextView desc = v.findViewById(R.id.tvDesc);
        TextView more = v.findViewById(R.id.tvMore);
        desc.setMaxLines(2);
        more.setText("more");
        more.setVisibility(Ui.nz(j.description).length() > 90 ? View.VISIBLE : View.GONE);
        more.setOnClickListener(x -> {
            boolean expand = desc.getMaxLines() == 2;
            desc.setMaxLines(expand ? Integer.MAX_VALUE : 2);
            more.setText(expand ? "less" : "more");
        });

        ImageButton save = v.findViewById(R.id.btnSave);
        ImageButton dis = v.findViewById(R.id.btnDislike);
        save.setImageResource(saved.contains(j.id) ? R.drawable.ic_heart : R.drawable.ic_heart_outline);
        Ui.press(save);
        Ui.press(dis);
        save.setOnClickListener(x -> {
            Ui.bounce(x);
            DatabaseReference r = root.child("userdata").child(uid).child("saved").child(j.id);
            if (saved.contains(j.id)) { saved.remove(j.id); r.removeValue(); }
            else { saved.add(j.id); r.setValue(true); }
            if (savedOnly) apply();
            else save.setImageResource(saved.contains(j.id) ? R.drawable.ic_heart : R.drawable.ic_heart_outline);
        });
        dis.setOnClickListener(x -> {
            hidden.add(j.id);
            root.child("userdata").child(uid).child("hidden").child(j.id).setValue(true);
            Toast.makeText(getContext(), "আর দেখানো হবে না", Toast.LENGTH_SHORT).show();
            apply();
        });
        v.setOnClickListener(x -> Ui.open(requireActivity(),
            new Intent(getActivity(), JobDetailActivity.class).putExtra("jobId", j.id)));
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        for (int i = 0; i < refs.size(); i++) refs.get(i).removeEventListener(ls.get(i));
        refs.clear();
        ls.clear();
        rv = null;
    }
}

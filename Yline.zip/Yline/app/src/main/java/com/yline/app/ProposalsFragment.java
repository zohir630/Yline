package com.yline.app;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.view.View;
import android.widget.TextView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.Collections;
import java.util.List;

public class ProposalsFragment extends BaseListFragment<Proposal> {
    @Override protected int itemLayout() { return R.layout.item_row; }
    @Override protected String emptyText() { return "আপনি এখনো কোনো proposal পাঠাননি"; }
    @Override protected DatabaseReference source() { return FirebaseDatabase.getInstance().getReference("proposals"); }

    @Override
    protected void collect(DataSnapshot snap, List<Proposal> out) {
        for (DataSnapshot d : snap.getChildren()) {
            Proposal p = d.getValue(Proposal.class);
            if (p != null && uid.equals(p.freelancerId)) { p.id = d.getKey(); out.add(p); }
        }
        Collections.sort(out, (a, b) -> Long.compare(b.timestamp, a.timestamp));
    }

    @Override
    protected void bind(View v, Proposal p) {
        ((TextView) v.findViewById(R.id.tvTitle)).setText(Ui.nz(p.jobTitle));
        ((TextView) v.findViewById(R.id.tvSub)).setText("Bid: $" + p.bid + "  •  " + Ui.nz(p.sellerName));
        ((TextView) v.findViewById(R.id.tvTime)).setText(Ui.timeAgo(p.timestamp));
        TextView b = v.findViewById(R.id.tvBadge);
        b.setVisibility(View.VISIBLE);
        b.setText(Ui.nz(p.status).toUpperCase());
        b.setBackgroundTintList(ColorStateList.valueOf(Ui.statusColor(p.status)));
    }

    @Override
    protected void onItemClick(Proposal p) {
        Ui.open(requireActivity(), new Intent(getActivity(), JobDetailActivity.class).putExtra("jobId", p.jobId));
    }
}
